RGB Cursor Pack (Roblox)
Created by ElliottTV

----------------------------------------

Description:
A RGB version of the original Roblox cursors, redesigned and customized for a clean and colorful look.

----------------------------------------

Contents:
- Full mouse cursor set
- Controller cursors
- Extra cursors (camera track, crosshair, etc.)

----------------------------------------

Installation:
1. Extract the ZIP file.
2. Open the "cursors" folder.
3. Import or replace your Roblox cursor files as needed.

(Note: Exact steps may vary depending on how you are using custom cursors.)

----------------------------------------

Notes:
- All cursors are designed to match in style and color.
- Optimized for consistency across mouse and controller.

----------------------------------------

Thank you for downloading!